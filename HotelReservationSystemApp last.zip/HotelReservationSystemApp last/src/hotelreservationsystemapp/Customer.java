
package hotelreservationsystemapp;


public class Customer {
    public static String name;
    public  String gender;
    public static String email;
    public  int nic;
    public  int tel;
    public static String pass;
    
   public Customer(String name,String gender,String email,int nic,int tel,String pass)
   {
       this.name=name;
       this.gender=gender;
       this.email=email;
       this.nic=nic;
       this.tel=tel;
       this.pass=pass;
       
       
   }
}