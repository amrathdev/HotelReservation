
package hotelreservationsystemapp;

import java.util.Date;


//Inheritance subclass
public class BuffetDetails extends Billing {
    public  String buffetType;
    public  Date eventDate;
    
    public BuffetDetails(String buffetType,Date eventDate)
    {
        this.buffetType=buffetType;
        this.eventDate=eventDate;
    }
    
    
    //OVER RIDING ABSTRACTION METHOD IN INHERITATED CLASS
     @Override
    public  long processPayment(String type) {
        long amount;
         switch (type) {
            case "Sit-down Buffet":
                amount=500000;
                break;
            case "Standing Buffet":
                amount=450000;
                break;
            case "Display Buffet":
                amount=400000;
                break;
            case "All-You-Can-Eat Buffet":
                amount=600000;
                break;
            case "International Buffet":
                amount=750000;
                break;
            case "Breakfast Buffet":
                amount=350000;
                break;
            case "Themed Buffet":
                amount=575000;
                break;
            default:
                amount=0;
                break;
        }
        return amount;
    }
}
