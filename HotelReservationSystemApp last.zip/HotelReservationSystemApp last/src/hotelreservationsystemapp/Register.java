package hotelreservationsystemapp;

import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;


public class Register extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Register.class.getName());
//Creates new form Register
    public Register() {
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        lbname = new javax.swing.JLabel();
        txtname = new javax.swing.JTextField();
        lbmail = new javax.swing.JLabel();
        txtmail = new javax.swing.JTextField();
        lbpass = new javax.swing.JLabel();
        lbtel = new javax.swing.JLabel();
        lbnic = new javax.swing.JLabel();
        txtnic = new javax.swing.JTextField();
        txttel = new javax.swing.JTextField();
        btnhome = new javax.swing.JButton();
        btnregister = new javax.swing.JButton();
        btnlogin = new javax.swing.JButton();
        txtpass = new javax.swing.JPasswordField();
        lbpass1 = new javax.swing.JLabel();
        txtconpass = new javax.swing.JPasswordField();
        rbfemale = new javax.swing.JRadioButton();
        lbname1 = new javax.swing.JLabel();
        rbmale = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Register");
        setIconImages(null);
        setPreferredSize(new java.awt.Dimension(900, 600));

        jPanel1.setPreferredSize(new java.awt.Dimension(900, 600));
        jPanel1.setLayout(null);

        lbname.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lbname.setText("GENDER");
        jDesktopPane1.add(lbname);
        lbname.setBounds(140, 210, 90, 30);
        lbname.getAccessibleContext().setAccessibleName("lbname");

        txtname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnameActionPerformed(evt);
            }
        });
        jDesktopPane1.add(txtname);
        txtname.setBounds(360, 170, 250, 30);
        txtname.getAccessibleContext().setAccessibleName("txtname");

        lbmail.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lbmail.setText("EMAIL");
        jDesktopPane1.add(lbmail);
        lbmail.setBounds(140, 250, 70, 30);
        lbmail.getAccessibleContext().setAccessibleName("lbemail");

        jDesktopPane1.add(txtmail);
        txtmail.setBounds(360, 250, 250, 30);
        txtmail.getAccessibleContext().setAccessibleName("txtemail");

        lbpass.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lbpass.setText("PASSWORD");
        jDesktopPane1.add(lbpass);
        lbpass.setBounds(140, 370, 120, 30);
        lbpass.getAccessibleContext().setAccessibleName("lbpassword");

        lbtel.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lbtel.setText("TELEPHONE NO");
        jDesktopPane1.add(lbtel);
        lbtel.setBounds(140, 330, 140, 21);
        lbtel.getAccessibleContext().setAccessibleName("lbTelno");

        lbnic.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lbnic.setText("NIC");
        jDesktopPane1.add(lbnic);
        lbnic.setBounds(140, 290, 100, 30);
        lbnic.getAccessibleContext().setAccessibleName("lbNic");

        txtnic.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnicActionPerformed(evt);
            }
        });
        jDesktopPane1.add(txtnic);
        txtnic.setBounds(360, 290, 250, 30);
        jDesktopPane1.add(txttel);
        txttel.setBounds(360, 330, 250, 30);
        txttel.getAccessibleContext().setAccessibleName("txttelno");

        btnhome.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnhome.setText("Home");
        btnhome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhomeActionPerformed(evt);
            }
        });
        jDesktopPane1.add(btnhome);
        btnhome.setBounds(210, 490, 100, 32);
        btnhome.getAccessibleContext().setAccessibleName("btnback");

        btnregister.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnregister.setText("OK");
        btnregister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnregisterActionPerformed(evt);
            }
        });
        jDesktopPane1.add(btnregister);
        btnregister.setBounds(500, 490, 100, 32);
        btnregister.getAccessibleContext().setAccessibleName("btnok");

        btnlogin.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnlogin.setText("Login");
        btnlogin.setPreferredSize(new java.awt.Dimension(72, 32));
        btnlogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnloginActionPerformed(evt);
            }
        });
        jDesktopPane1.add(btnlogin);
        btnlogin.setBounds(350, 490, 100, 30);
        btnlogin.getAccessibleContext().setAccessibleName("btnlogin");

        jDesktopPane1.add(txtpass);
        txtpass.setBounds(360, 370, 250, 30);

        lbpass1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lbpass1.setText("CONFIRM PASSWORD");
        jDesktopPane1.add(lbpass1);
        lbpass1.setBounds(140, 410, 200, 30);
        jDesktopPane1.add(txtconpass);
        txtconpass.setBounds(360, 410, 250, 30);

        rbfemale.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        rbfemale.setText("Female");
        jDesktopPane1.add(rbfemale);
        rbfemale.setBounds(480, 210, 98, 27);

        lbname1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lbname1.setText("NAME");
        jDesktopPane1.add(lbname1);
        lbname1.setBounds(140, 170, 70, 30);

        rbmale.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        rbmale.setText("Male");
        jDesktopPane1.add(rbmale);
        rbmale.setBounds(360, 210, 98, 27);

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 0, 36)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/oop icon/icons8-register-100.png"))); // NOI18N
        jLabel1.setText("REGISTER");
        jDesktopPane1.add(jLabel1);
        jLabel1.setBounds(340, 50, 280, 110);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelreservationsystemapp/back2.jpg"))); // NOI18N
        jDesktopPane1.add(jLabel6);
        jLabel6.setBounds(0, 0, 900, 640);
        jLabel6.getAccessibleContext().setAccessibleName("txtNic");

        jPanel1.add(jDesktopPane1);
        jDesktopPane1.setBounds(0, 0, 900, 640);
        jDesktopPane1.getAccessibleContext().setAccessibleName("lbname");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnameActionPerformed

    private void txtnicActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnicActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnicActionPerformed

    private void btnhomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhomeActionPerformed
        // TODO add your handling code here:
            dispose();           // To close the register form
            Home home = new Home();  //creating object 
        home.setVisible(true); 
        
    }//GEN-LAST:event_btnhomeActionPerformed

    private void btnloginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnloginActionPerformed
        // TODO add your handling code here:
            dispose();        // To close the register form
            Login login = new Login();
        login.setVisible(true);
        
    }//GEN-LAST:event_btnloginActionPerformed

    private void btnregisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnregisterActionPerformed
        // TODO add your handling code here:
        String name=txtname.getText();
        String email=txtmail.getText();
        int nic;
        int tel;
        try {
            nic= Integer.parseInt(txtnic.getText());
            tel= Integer.parseInt(txttel.getText());
} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(this, "Invalid input. Please enter a valid number.");
    nic=0;
    tel=0;
}
        String pass = new String(txtpass.getPassword());
        String conpass = new String(txtconpass.getPassword());
        String gender="";
        if (rbmale.isSelected())
            {
                 gender="Male";
            }
        else if (rbfemale.isSelected())
            {
                 gender="Female";
            }
        Customer cus= new Customer(name,gender,email,nic,tel,pass);
        
        if ("".equals(name) ||"".equals(email) ||nic==0 ||tel==0||"".equals(gender) ||"".equals(pass) ||"".equals(conpass))
        {
            JOptionPane.showMessageDialog(this, "Fill the details");
        }
        else
        {
            
            
            if (pass.equals(conpass))
            {
                JOptionPane.showMessageDialog(this, "Registration Success");
                dispose();
                new Login().setVisible(true);
            }
            else
            {
                JOptionPane.showMessageDialog(this, "Password doesn't match");
                pass=null;
                conpass=null;
            }
        }
    }//GEN-LAST:event_btnregisterActionPerformed

    
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(() -> new Register().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnhome;
    private javax.swing.JButton btnlogin;
    private javax.swing.JButton btnregister;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lbmail;
    private javax.swing.JLabel lbname;
    private javax.swing.JLabel lbname1;
    private javax.swing.JLabel lbnic;
    private javax.swing.JLabel lbpass;
    private javax.swing.JLabel lbpass1;
    private javax.swing.JLabel lbtel;
    private javax.swing.JRadioButton rbfemale;
    private javax.swing.JRadioButton rbmale;
    private javax.swing.JPasswordField txtconpass;
    private javax.swing.JTextField txtmail;
    private javax.swing.JTextField txtname;
    private javax.swing.JTextField txtnic;
    private javax.swing.JPasswordField txtpass;
    private javax.swing.JTextField txttel;
    // End of variables declaration//GEN-END:variables
}
