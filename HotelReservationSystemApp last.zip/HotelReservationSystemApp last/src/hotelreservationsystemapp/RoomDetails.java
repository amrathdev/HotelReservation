
package hotelreservationsystemapp;

import java.util.Date;
//Inheritance subclass

public class RoomDetails extends Billing {
    public static String roomType;
    public static long roomQuantity;
    public static Date checkin;
    public static Date checkout;
    public static long hours;
    
    //OVER RIDING ABSTRACTION METHOD IN INHERITATED CLASS
    @Override
    public  long processPayment(String type) {
        long amount;
        switch (type) {
            case "Single":
                amount=1000;
                break;
            case "Double":
                amount=2000;
                break;
            case "Family":
                amount=3000;
                break;
            default:
                amount=0;
                break;
        }
        amount=amount*roomQuantity*hours;
        return amount;
    }
    
    
}
