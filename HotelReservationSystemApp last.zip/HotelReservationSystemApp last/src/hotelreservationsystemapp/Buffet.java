/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package hotelreservationsystemapp;

import java.util.Date;

/**
 *
 * @author admin
 */
public class Buffet extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Buffet.class.getName());

    /**
     * Creates new form Buffet
     */
    public Buffet() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cmbtype = new javax.swing.JComboBox<>();
        btnconfirm = new javax.swing.JButton();
        btnback = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        spedate = new javax.swing.JSpinner();
        txtamount = new javax.swing.JTextField();
        txtname = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setPreferredSize(new java.awt.Dimension(900, 600));
        jPanel2.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 36)); // NOI18N
        jLabel1.setText("Buffet Booking");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(300, 60, 273, 48);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setText("Customer Name");
        jPanel2.add(jLabel3);
        jLabel3.setBounds(250, 190, 142, 25);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setText("Event Date");
        jPanel2.add(jLabel4);
        jLabel4.setBounds(250, 270, 100, 25);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setText("Buffet Type");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(250, 230, 110, 25);

        cmbtype.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cmbtype.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sit-down Buffet", "Standing Buffet", "Display Buffet", "All-You-Can-Eat Buffet", "International Buffet", "Breakfast Buffet", "Themed Buffet", " ", " ", " " }));
        jPanel2.add(cmbtype);
        cmbtype.setBounds(450, 230, 170, 24);

        btnconfirm.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        btnconfirm.setText("Confrim");
        btnconfirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnconfirmActionPerformed(evt);
            }
        });
        jPanel2.add(btnconfirm);
        btnconfirm.setBounds(470, 400, 120, 27);

        btnback.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        btnback.setText("Back");
        btnback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbackActionPerformed(evt);
            }
        });
        jPanel2.add(btnback);
        btnback.setBounds(290, 400, 120, 27);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel7.setText("Amount");
        jPanel2.add(jLabel7);
        jLabel7.setBounds(250, 310, 73, 25);

        spedate.setModel(new javax.swing.SpinnerDateModel(new java.util.Date(), new java.util.Date(), new java.util.Date(1752601680000L), java.util.Calendar.DAY_OF_MONTH));
        jPanel2.add(spedate);
        spedate.setBounds(450, 270, 180, 22);

        txtamount.setEditable(false);
        jPanel2.add(txtamount);
        txtamount.setBounds(450, 310, 170, 30);

        txtname.setEditable(false);
        jPanel2.add(txtname);
        txtname.setBounds(450, 190, 170, 30);

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelreservationsystemapp/back2.jpg"))); // NOI18N
        jPanel2.add(jLabel10);
        jLabel10.setBounds(0, 0, 900, 600);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 900, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 600, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbackActionPerformed
        // TODO add your handling code here:
            dispose();           // Close current Home frame
            Menu menu = new Menu();
            menu.setVisible(true);
        
    }//GEN-LAST:event_btnbackActionPerformed

    private void btnconfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnconfirmActionPerformed
        // TODO add your handling code here:
        txtname.setText(String.valueOf(Customer.name));
        String buffetType=(String) cmbtype.getSelectedItem();
        Date eventDate=(Date) spedate.getValue();
        
        long amount;
        BuffetDetails payment = new BuffetDetails(buffetType,eventDate);
        amount=payment.processPayment(buffetType);
        txtamount.setText(String.valueOf(amount));

    }//GEN-LAST:event_btnconfirmActionPerformed

    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(() -> new Buffet().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnback;
    private javax.swing.JButton btnconfirm;
    private javax.swing.JComboBox<String> cmbtype;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSpinner spedate;
    private javax.swing.JTextField txtamount;
    private javax.swing.JTextField txtname;
    // End of variables declaration//GEN-END:variables
}
