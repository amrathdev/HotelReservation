
package hotelreservationsystemapp;

import java.util.Date;

//Inheritance subclass
public class HallDetails extends Billing {
    public  String hallType;
    public  Date eventDate;
    
    //constructor
    public HallDetails (String hallType,Date eventDate)
    {
        this.hallType=hallType;
        this.eventDate=eventDate;
    }
    
    //OVER RIDING ABSTRACTION METHOD IN INHERITATED CLASS
     @Override
    public  long processPayment(String type) {
        long amount;
         switch (type) {
            case "Wedding":
                amount=500000;
                break;
            case "Reception":
                amount=450000;
                break;
            case "Birthday Party":
                amount=100000;
                break;
            case "Office Party":
                amount=150000;
                break;
            default:
                amount=0;
                break;
        }
        return amount;
    }
}
